# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'cf0a48e12a08749549f81732eac02142adc7ef0d6bd97931c19c476412137b60c165d69980c742c6f97b3907fb14a7b714fe8148e101c27296f6dd8d1e718cf8'